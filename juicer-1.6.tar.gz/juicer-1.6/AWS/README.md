Extensive instructions, including how to create and launch an instance, are 
available [on the wiki](https://github.com/theaidenlab/juicer/wiki/Running-Juicer-on-Amazon-Web-Services)
