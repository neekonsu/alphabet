# Juicer single CPU version BETA

**BETA VERSION** 

Report bugs using the Issues tab. 

Follow the documentation on [the wiki](https://github.com/theaidenlab/juicer/wiki/Installation) for dependencies, directory structure, and usage.

**PLEASE NOTE:**  The CPU version is fine for small Hi-C experiments, but any reasonably sized experiment will take an extremely long time to run and therefore should be run [on a cluster](https://github.com/theaidenlab/juicer/wiki/Running-Juicer-on-a-cluster) or [in the cloud](https://github.com/theaidenlab/juicer/wiki/Running-Juicer-on-Amazon-Web-Services).
