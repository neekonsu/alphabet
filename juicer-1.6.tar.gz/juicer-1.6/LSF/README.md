# Juicer LSF (BETA)

**BETA VERSION**

**NOTE THAT DEVELOPMENT OF THE LSF BRANCH WILL ALWAYS BE BEHIND THE OTHER VERSIONS**

We do not use LSF in our lab.  We welcome other developers to update the LSF version to be consistent with the AWS LSF-like version.

Report bugs using the Issues tab. See the [documentation on the wiki](https://github.com/theaidenlab/juicer/wiki/Running-Juicer-on-a-cluster) to understand how to install and run Juicer.
