Please see the [wiki](https://github.com/theaidenlab/juicer/wiki/Running-Juicer-on-a-cluster) for extensive instructions
